<?php
    include_once(__DIR__."/view/include/header.php");
?> 

<div class="row">
    <div class="col-lg-6  col-sm-12 alert alert-primary">
        infor1
    </div>
    <div class="col-lg-3 col-sm-6 alert alert-primary">
        infor2
    </div>
    <div class="col-lg-3 col-sm-6 alert alert-primary">
        infor3
    </div>
</div>
    
<?php
    include_once(__DIR__."/view/include/footer.php");
?>