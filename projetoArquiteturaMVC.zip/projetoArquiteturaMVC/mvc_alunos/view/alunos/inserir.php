<?php

include_once(__DIR__."/../../model/Aluno.php");
include_once(__DIR__."/../../controller/AlunoController.php");


$mgsErros = "";
$aluno = NULL;

if(isset($_POST['nome'])){
    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : NULL;
    $idade = is_numeric($_POST['idade']) ? $_POST['idade'] : NULL;
    $estrageiro = trim($_POST['estrageiro']) ? trim($_POST['estrageiro']) : NULL;
    $idCurso = is_numeric($_POST['curso']) ? $_POST['curso'] : NULL;


    $aluno = new Aluno();
    $aluno->setId(0);
    $aluno->setNome($nome);
    $aluno->setIdade($idade);
    $aluno->setEstrangeiro($estrageiro);
    $curso = new Curso();
    $curso->setId($idCurso);
    $aluno->setCurso($curso);

    $alunoCont = new AlunoController;
    $erro = $alunoCont->salvar($aluno);

    if(empty($erro)){
        header("location: listar.php");
        exit;
    }else{
        $mgsErros = implode("<br>", $erro);
    }


    $mgsErros = implode("<br>", $erro);


}

include_once(__DIR__ . "/form.php");


?>