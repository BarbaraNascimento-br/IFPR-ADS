<?php

include_once(__DIR__ . "/../../model/Aluno.php");
include_once(__DIR__ . "/../../controller/AlunoController.php");

$mgsErros = "";
$aluno = NULL;

if(isset($_POST['nome'])) {

    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : NULL;
    $idade = is_numeric($_POST['idade']) ? $_POST['idade'] : NULL;
    $estrageiro = trim($_POST['estrageiro']) ? trim($_POST['estrageiro']) : NULL;
    $idCurso = is_numeric($_POST['curso']) ? $_POST['curso'] : NULL;
    $idAluno = $_POST['id'];


    $aluno = new Aluno();
    $aluno->setId($idAluno);
    $aluno->setNome($nome);
    $aluno->setIdade($idade);
    $aluno->setEstrangeiro($estrageiro);
    $curso = new Curso();
    $curso->setId($idCurso);
    $aluno->setCurso($curso);

    $alunoCont = new AlunoController;
    $erro = $alunoCont->alterar($aluno);

    if(empty($erro)){
        header("location: listar.php");
        exit;
    }else{
        $mgsErros = implode("<br>", $erro);
    }


    $mgsErros = implode("<br>", $erro);
    

} else {
    
    $id = 0;
    if(isset($_GET["id"]))
        $id = $_GET["id"];

    if(! $id) {
        echo "ID inválido!<br>";
        echo "<a href='listar.php'>Voltar</a>";
        exit;
    }

    $alunoCont = new AlunoController();
    $aluno = $alunoCont->buscarPorAluno($id);

    if(! $id) {
        echo "ID inválido!<br>";
        echo "<a href='listar.php'>Voltar</a>";
        exit;
    }

    
}

include_once(__DIR__ . "/form.php");