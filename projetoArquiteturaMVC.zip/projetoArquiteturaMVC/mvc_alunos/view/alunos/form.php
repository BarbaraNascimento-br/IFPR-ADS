<?php

include_once(__DIR__ . "/../../controller/CursoController.php");
include_once(__DIR__ . "/../../model/Aluno.php");

$cursoCont = new CursoController();
$cursos = $cursoCont->listarCursos();

include_once(__DIR__ . "/../include/header.php");
?>

<h3><?= $aluno && $aluno->getId() > 0 ? "Alterar" : "Inserir" ?> Aluno</h3>

<div class="row">
    <div class="col-6">
        <form action="" method="POST">

            <div>
                <label for="" class="form-control">NOME:</label>
                <input type="text" name="nome" id="nome" value="<?= $aluno ? $aluno->getNome() : '' ?>">
            </div>

            <br>

            <div>
                <label for="" class="form-control">IDADE:</label>
                <input type="number" name="idade" id="idade" value="<?= $aluno ? $aluno->getIdade() : '' ?>">
            </div>

            <br>

            <div>
                <label for="" class="form-control">ESTRANGEIRO</label>
                <select name="estrageiro" id="estrageiro">
                    <option value="">--Selecione--</option>
                    <option value="S" <?= $aluno && $aluno->getEstrangeiro() == 'S' ? "selected" : "" ?>>sim</option>
                    <option value="N" <?= $aluno && $aluno->getEstrangeiro() == 'N' ? "selected" : "" ?>>não</option>
                </select>
            </div>

            <br>

            <div>
                <label for="" class="form-control">CURSO</label>
                <select name="curso" id="curso">
                    <option value="">--Selecione--</option>
                    <!--Opção geradas de forma dinâmica-->
                    <?php foreach ($cursos as $c): ?>
                        <option value="<?= $c->getId() ?>"

                            <?php if ($aluno && $aluno->getCurso()->getId() == $c->getId())
                                echo "selected";

                            ?>><?= $c ?>/option>

                        <?php endforeach ?>

                </select>
            </div>

            <div>
                <input type="hidden" name="id" id="id" value="<?= $aluno ? $aluno->getId() : 0 ?>">
            </div>

            <div class="mt-3">
                <button class="btn btn-success">Gravar</button>
            </div>

        </form>
    </div>

    <div class="col-6">
        <?php if ($mgsErros) : ?>
            <div class="alert alert-danger">
                <?= $mgsErros ?>
            </div>
        <?php endif ?>
    </div>

</div>

<a href="listar.php" class="btn btn-outline-secondary mt-3">Voltar</a>



<?php
include_once(__DIR__ . "/../include/footer.php");
?>