<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include_once(__DIR__."/../../controller/AlunoController.php");

$alunoCont = new AlunoController();
$aluno = $alunoCont->listar();


include_once(__DIR__ . "/../include/header.php");
 ?>
<h3>Listar Alunos</h3>

<a href="inserir.php" class="btn btn-primary" >inserir</a>

<table border="1" class="table table-striped-columns">
    <tr>
        <td>ID</td>
        <td>NOME</td>
        <td>IDADE</td>
        <td>ESTRANGEIRO</td>
        <td>CURSO</td>
        <td></td>
        <td></td>
    </tr>

    <?php foreach($aluno as $a): ?>
    
     <tr>
        <td><?=  $a->getId()?></td>
        <td><?=  $a->getNome()?></td>
        <td><?=  $a->getIdade()?></td>
        <td><?=  $a->getEstrangeiroDesc()?></td>
        <td><?= $a->getCurso()?></td>
        <td><a href="alterar.php?id=<?=  $a->getId()?>"><img src="../../img/btn_editar.png"></a></td>
        <td><a href="excluir.php?id=<?=  $a->getId()?>"><img src="../../img/btn_excluir.png" onclick="return confirm('Confirma a exclusão?')"></a></td>
    </tr>

    <?php endforeach; ?>
   
</table>

<?php

include_once(__DIR__ . "/../include/footer.php");




?>
 