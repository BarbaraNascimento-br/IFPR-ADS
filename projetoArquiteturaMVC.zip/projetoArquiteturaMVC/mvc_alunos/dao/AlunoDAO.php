<?php

include_once(__DIR__ . "/../util/Connection.php");
include_once(__DIR__ . "/../model/Aluno.php");


class AlunoDAO{



    public function listar(){
        $sql = "SELECT a.*, c.nome nome_curso, c.turno turno_curso 
                FROM alunos a
                JOIN cursos c ON (c.id = a.id_curso)";

        $conexao = Connection::getConnection();
        $stml = $conexao->prepare($sql);
        $stml->execute();
        $result = $stml->fetchAll();

        $alunos = $this->map($result);

        return $alunos;
    }

    public function buscarPorId(int $id){
                
        $sql = "SELECT a.*, 
                    c.nome nome_curso, c.turno turno_curso  
                FROM alunos a
                JOIN cursos c ON (c.id = a.id_curso)
                WHERE a.id = ?";
        $conn = Connection::getConnection();

        $stmt = $conn->prepare($sql);
        $stmt->execute([$id]);
        $result = $stmt->fetchAll();

        //Criar o objeto Aluno
        $alunos = $this->map($result);

        if(count($alunos) == 1)
            return $alunos[0];
        elseif(count($alunos) == 0)
            return null;

        die("AlunoDAO.findById - Erro: mais de um aluno".
                " encontrado para o ID " . $id);
    }

    public function map(array $dados){
        $alunos = array();

        foreach($dados as $d){
            $aluno = new Aluno();
            $aluno->setId($d["id"]);
            $aluno->setNome($d["nome"]);
            $aluno->setEstrangeiro($d["estrangeiro"]);
            $aluno->setIdade($d["idade"]);

            $curso = new Curso();
            $curso->setId($d["id_curso"]);
            $curso->setNome($d["nome_curso"]);
            $curso->setTurno($d["turno_curso"]);
            $aluno->setCurso($curso);

            array_push($alunos, $aluno);
            
        }
        return $alunos;
    }

    public function inserir(Aluno $aluno){

        try{
            $sql = "INSERT INTO alunos(nome, idade, estrangeiro, id_curso) VALUES(?, ?, ?, ?)";
            $conexao = Connection::getConnection();
            $stmt = $conexao->prepare($sql);
            $stmt->execute(array($aluno->getNome(), $aluno->getIdade(), $aluno->getEstrangeiro(), $aluno->getCurso()->getId()));
        }catch(PDOException $e){
            return "Erro ao inserir o aluno!" . $e->getMessage();
        }

        return "";
    }

    public function alterar(Aluno $aluno) {
        $conn = Connection::getConnection();

        $sql = "UPDATE alunos 
                SET nome = ?, idade = ?, estrangeiro = ?, id_curso = ?
                WHERE id = ?";
        $stmt = $conn->prepare($sql);
        
        try {
            $stmt->execute([$aluno->getNome(), $aluno->getIdade(), 
                            $aluno->getEstrangeiro(), $aluno->getCurso()->getId(),
                            $aluno->getId()]);
        } catch (PDOException $e) {
            return "Erro ao alterar o aluno! " . $e->getMessage();
        }

        return "";
    }

    public function excluir(int $id){
        
        try{
            $sql = "DELETE FROM alunos WHERE id = ?";
            $conexao = Connection::getConnection();
            $stmt = $conexao->prepare($sql);
            $stmt->execute(array($id));
        }catch(PDOException $e){
            return "Erro ao excluir!" . $e->getMessage();
        }

        return "";
    }

    
}