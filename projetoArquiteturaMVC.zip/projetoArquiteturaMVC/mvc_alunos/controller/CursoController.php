<?php

include_once(__DIR__ . "/../dao/CursoDAO.php");

class CursoController{

    private CursoDAO $cursodao;


    public function __construct(){
            $this->cursodao = new CursoDAO;
    }


    public  function listarCursos(){

        return $this->cursodao->listar();
    }
}