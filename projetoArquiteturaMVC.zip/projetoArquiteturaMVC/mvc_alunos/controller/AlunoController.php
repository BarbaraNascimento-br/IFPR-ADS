<?php

include_once(__DIR__ . "/../dao/AlunoDAO.php");
include_once(__DIR__ . "/../model/Aluno.php");
include_once(__DIR__ . "/../service/AlunoService.php");

class AlunoController{

    private AlunoDAO $alunoDAO;
    private AlunoService $aluno_service;

    public function __construct(){
        $this->alunoDAO = new AlunoDAO;
        $this->aluno_service = new AlunoService;
    }

    public function listar(){
        return $this->alunoDAO->listar();
    }

    public function buscarPorAluno(int $id) : ?Aluno  {
        return $this->alunoDAO->buscarPorId($id);
    }

    public function salvar(Aluno $aluno){

        $validacao = $this->aluno_service->validar($aluno);

        if(empty($validacao)){
            
        $msgErro = $this->alunoDAO->inserir($aluno);

            if($msgErro)
                array_push($validacao, $msgErro);
        }

        return $validacao;

    }

    public function alterar(Aluno $aluno){
        
        $validacao = $this->aluno_service->validar($aluno);

        if(empty($validacao)){
            
        $msgErro = $this->alunoDAO->alterar($aluno);

            if($msgErro)
                array_push($validacao, $msgErro);
        }

        return $validacao;

    }

    public function excluir(int $id){
        
        return $this->alunoDAO->excluir($id);

    }


}