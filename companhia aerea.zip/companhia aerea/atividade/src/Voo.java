import java.util.ArrayList;
import java.util.List;

public class Voo {

    private int capacidadeMaximaDePassageiros = 50;
    private int contadorDePassageiros = 0;

    private String codigo;
    private String embarque;
    private String desembarque;
    private Companhia companhia;
    private Passageiro[] passageiros = new Passageiro[capacidadeMaximaDePassageiros];


    public Voo(String codigo, String embarque, String desembarque, Companhia companhia) {
        this.codigo = codigo;
        this.embarque = embarque;
        this.desembarque = desembarque;
        this.companhia = companhia;
    }

    public String getCodigo() {

        return codigo;
    }

    public String getEmbarque() {

        return embarque;
    }

    public String getDesembarque() {

        return desembarque;
    }

    public Companhia getCompanhia() {

        return companhia;
    }

    public int getCapacidade() {
        return capacidadeMaximaDePassageiros;
    }

    public Passageiro[] getPassageiros() {
        return passageiros;
    }

    public void listarPassageiros() {
        System.out.println("[");
        for (int i = 0; i < contadorDePassageiros; i++) {
            System.out.println(passageiros[i] + ",");

        }
        System.out.println("]");
    }

    public boolean adicionarPassageiro(Passageiro passageiro) {
        if (contadorDePassageiros >= capacidadeMaximaDePassageiros) {
            return false;
        }
        passageiros[contadorDePassageiros] = passageiro;
        contadorDePassageiros++;
        return true;
    }

    @Override
    public String toString() {
        return "[" + codigo + ", " + embarque + " -> " + desembarque + "]";

    }
}