import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {

        int opcao = 0;
        int contadorDeVoos = 0;

        BufferedReader ler = new BufferedReader(new InputStreamReader(System.in));

        Menus menus = new Menus();

        int cnpj;
        String nome;
        do {
            System.out.println("Nome da companhia: ");
            nome = (ler.readLine());
            System.out.println("Cnpj da companhia: ");
            cnpj = (Integer.parseInt(ler.readLine()));

            if(nome.isBlank() || cnpj <= 0){
                System.out.println("Nome e cnpj devem ser preenchidos e o cnpj deve ser maior que 0");
            }

        } while (nome.isBlank() || cnpj <= 0);

        Companhia companhia = new Companhia(nome, cnpj);

        if (companhia.getNome().equals("gol") || companhia.getNome().equals("GOL"))
            menus.gol();

        if (companhia.getNome().equals("azul") || companhia.getNome().equals("AZUL"))
            menus.azul();

        while (opcao != 4){
            menus.menu();
            System.out.println("Escolha uma opção: ");
            opcao = Integer.parseInt(ler.readLine());

            switch (opcao){
                case 1:

                    for (int i = 0; i < 1 ;i++){ //companhia.getCapacidadeMaximaDeVoos()
                        String embarque;
                        String destino;

                        menus.menuVoo();

                        do {

                            System.out.println("Seu embarque: ");
                            embarque = (ler.readLine());

                            System.out.println("Seu destino: ");
                            destino = (ler.readLine());

                            if (embarque.isBlank() || destino.isBlank()) System.out.println("Seu embarque e destino devem ser preenchidos");

                        }while (embarque.isBlank() || destino.isBlank());

                        companhia.adicionarVoo(new Voo(companhia.gerarCodigo(), embarque, destino, companhia));
                        System.out.println("Voo cadastrado com sucesso!");

                        menus.menuPassageiro();

                        String continuar = "";
                        int assentosLivres = 0;
                        do {
                            System.out.println("Nome do passageiro: ");
                            String nomePassageiro = (ler.readLine());
                            System.out.println("CPF do passageiro: ");
                            String cpf = (ler.readLine());
                            System.out.println("Telefone do passageiro: ");
                            String telefone = (ler.readLine());

                            boolean adicionar = companhia.getVoo(i).adicionarPassageiro(new Passageiro(nomePassageiro, cpf, telefone));

                            if (adicionar == true) {
                                System.out.println("Passageiro cadastrado com sucesso!");
                                assentosLivres++;
                                System.out.println("-----------------------------------------");
                                System.out.println("| Quantidade de assentos livres : " + (companhia.getVoo(i).getCapacidade() - assentosLivres) + "|");
                                System.out.println("-----------------------------------------");
                            } else {
                                System.out.println("Capacidade máxima de passageiros atingida.");
                            }

                            System.out.println("Deseja adicionar mais um passageiro? (s/n)");
                            continuar = (ler.readLine());

                        }while (continuar.equals("s") || continuar.equals("S"));

                    contadorDeVoos++;
                    }
                    break;
                case 2:
                    if (companhia.getContadorDeVoos() == 0) {
                        System.out.println("Nenhum voo cadastrado.");
                    }
                    for (int i = 0; i < companhia.getContadorDeVoos(); i++) {
                        Voo v = companhia.getVoo(i);
                        System.out.println(v.getCodigo() + " | " + v.getEmbarque()
                                + " -> " + v.getDesembarque());
                        companhia.getVoo(i).listarPassageiros();
                    }
                    break;
                case 3:
                    System.out.println("Digite o código do voo: ");
                    String codigo = ler.readLine();
                    companhia.getVooPorCodigo(codigo, contadorDeVoos);
                    break;
                case 4:
                    System.out.println("Saindo ...");
                    break;
                default:
                    System.out.println("Opção inválida");
                    break;
            }
        }



    }
}