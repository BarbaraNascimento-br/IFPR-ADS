import java.util.ArrayList;
import java.util.List;

public class Companhia {

    private int capacidadeMaximaDeVoos = 10;
    private int contadorDeVoos = 0;

    private String nome;
    private int cnpj;
    private Voo[] voos = new Voo[capacidadeMaximaDeVoos];


    private String sigla = "IFPR_JAVA" ;
    private int proximoNumero = 100;

    public Companhia(String nome, int cnpj) {
        this.nome = nome;
        this.cnpj = cnpj;
        this.voos = new Voo[capacidadeMaximaDeVoos];
    }

    public String getNome() {
        return nome;
    }

    public int getCnpj() {
        return cnpj;
    }

    public Voo[] getVoos() {
        return voos;
    }

    public void  getVooPorCodigo(String codigo, int contadorDeVoos) {

        for (int i = 0; i < contadorDeVoos; i++) {
            if (voos[i].getCodigo().equals(codigo)) {
                System.out.println(voos[i]);
                voos[i].listarPassageiros();
                return;
            }
        }
        System.out.println("Voo não encontrado");
    }

    public int getCapacidadeMaximaDeVoos() {
        return capacidadeMaximaDeVoos;
    }

    public int getContadorDeVoos() {
        return contadorDeVoos;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCnpj(int cnpj) {
        this.cnpj = cnpj;
    }

    public boolean adicionarVoo(Voo voo) {
        if (contadorDeVoos >= capacidadeMaximaDeVoos) {
            return false;
        }
        voos[contadorDeVoos] = voo;
        contadorDeVoos++;
        return true;
    }

    public String gerarCodigo() {

        return sigla + String.format("%03d", proximoNumero++);
    }

    public Voo getVoo(int i) {
        return voos[i];
    }
}
