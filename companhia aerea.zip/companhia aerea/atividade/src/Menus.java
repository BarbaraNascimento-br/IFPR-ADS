public class Menus {

    public void menu(){
        System.out.println("========== VOOS ===========");
        System.out.println("1.CADASTRAR VÔO");
        System.out.println("2.LISTAR VÔOS");
        System.out.println("3.CONSULTAR UM DETERMINADO VÔO");
        System.out.println("4.VOLTAR");
    }

    public void menuPassageiro(){
        System.out.println("========== ADICIONANDO PASSAGEIRO ===========");
    }

    public void menuVoo(){
        System.out.println("========== ADICIONANDO Voo ===========");
    }

    public void gol(){
        System.out.println("""
             ---    ---   -   \s 
            -      -   -  -   \s
            - --   -   -  -   \s
            -   -  -   -  -   \s 
             ---    ---   -----""");
    }

    public void azul(){
        System.out.println("""
         ++   ++++  +  +  +   \s
        +  +     +  +  +  +   \s
        ++++    +   +  +  +   \s
        +  +   +    +  +  +   \s
        +  +   ++++  ++   ++++""");
    }
}
