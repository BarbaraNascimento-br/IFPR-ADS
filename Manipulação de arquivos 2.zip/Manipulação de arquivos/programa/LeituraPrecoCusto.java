import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class LeituraPrecoCusto {

    private String nomeArquivoDeEntrada = "preco_custo.csv";
    private String nomeArquivoDeSaida;
    private String linhaEntrada;
    private String cabecalhoSaida = "código;nome;preço_de_venda";
    private String arquicoCompras = "comprar.csv";
    private String cabecalhoComprar = "codigo;estoque;produto;preco_custo;categoria";
    private String linhaSaidaComprar;
    private String linhaSaida;


    public void calcularMargemPrecoVenda(double margem, String nome) throws Exception {

        if (margem <= 0) {
            throw new Exception("Margem deve ser maior que 0");
        }

        if (nome.equals("")){
            nome = "preco_venda2";
        }


        nomeArquivoDeSaida = nome + ".csv";

        BufferedReader arqLeitura = new BufferedReader(new FileReader((nomeArquivoDeEntrada)));
        BufferedWriter arqEscrita = new BufferedWriter(new FileWriter(nomeArquivoDeSaida));
        BufferedWriter arqEscritaComprar = new BufferedWriter(new FileWriter(arquicoCompras));

        linhaEntrada = arqLeitura.readLine();

        arqEscritaComprar.write(cabecalhoComprar);
        arqEscritaComprar.newLine();
        arqEscrita.write(cabecalhoSaida);
        arqEscrita.newLine();
        while ((linhaEntrada = arqLeitura.readLine()) != null){

            String[] vetCampo = linhaEntrada.split(";");

            //System.out.println(vetCampo[1].getClass().getName());

            int estoque = Integer.parseInt(vetCampo[1]);

            if (estoque < 10){

                linhaSaidaComprar = vetCampo[0] + ";" + vetCampo[1] + ";" + vetCampo[2] + ";" + vetCampo[3] + ";" + vetCampo[4];
                arqEscritaComprar.write(linhaSaidaComprar);
                arqEscritaComprar.newLine();

            }

            double precoCusto = Double.parseDouble(vetCampo[3].replace(",", "."));
            double precoVenda = (precoCusto + (precoCusto * (margem/100)));

            String precoVendaString = String.format("%.2f", precoVenda).replace(".", ",");

            linhaSaida = vetCampo[0] + ";" + vetCampo[2] + ";" + precoVendaString;
            arqEscrita.write(linhaSaida);
            arqEscrita.newLine();


        }

        arqLeitura.close();
        arqEscritaComprar.close();
        arqEscrita.close();
    }

}
