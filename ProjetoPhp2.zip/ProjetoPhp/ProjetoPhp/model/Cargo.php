<?php

include_once(__DIR__."/Turno.php");

class cargo{
    private ?int $id;
    private ?string $nome;
    private ?string $setor;
    private ?Turno $turno;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    public function getNome(): ?string
    {
        return $this->nome;
    }

    public function setNome(?string $nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    public function getSetor(): ?string
    {
        return $this->setor;
    }

    public function setSetor(?string $setor): self
    {
        $this->setor = $setor;

        return $this;
    }

    public function getTurno(): ?Turno
    {
        return $this->turno;
    }

    public function setTurno(?Turno $turno): self
    {
        $this->turno = $turno;

        return $this;
    }

    


}