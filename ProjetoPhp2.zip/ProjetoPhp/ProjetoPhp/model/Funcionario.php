<?php

include_once(__DIR__."/Cargo.php");

final class Funcionario {
    pri
    vate ?int $id;
    private ?string $nome;
    private ?string $setor;
    private ?Cargo $cargo;

    public function getId(): ?int
    {
        return $this->id;
    }
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }
    public function getNome(): ?string
    {
        return $this->nome;
    }
    public function setNome(?string $nome): self
    {
        $this->nome = $nome;

        return $this;
    }
    public function getSetor(): ?string
    {
        return $this->setor;
    }
    public function setSetor(?string $setor): self
    {
        $this->setor = $setor;

        return $this;
    }
    public function getCargo(): ?Cargo
    {
        return $this->cargo;
    }
    public function setCargo(?Cargo $cargo): self
    {
        $this->cargo = $cargo;

        return $this;
    }
    
    
}
