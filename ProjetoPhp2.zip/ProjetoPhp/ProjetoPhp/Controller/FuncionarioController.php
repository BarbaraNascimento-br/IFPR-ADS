<?php

class FuncionarioController
{
    public function list()
    {
        // Lógica para listar funcionários
    }

    public function create()
    {
        // Lógica para exibir o formulário de criação de funcionário
    }

    public function update($id)
    {
        // Lógica para atualizar um funcionário existente
    }

    public function delete($id)
    {
        // Lógica para excluir um funcionário
    }
}