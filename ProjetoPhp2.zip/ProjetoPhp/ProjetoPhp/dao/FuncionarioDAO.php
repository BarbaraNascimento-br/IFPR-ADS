<?php

include_once(_DIR_ . '/../model/Funcionario.php');
include_once(_DIR_ . '/../util/Connection.php');

class FuncionarioDAO
{
    public function list(){
        // Lógica para listar funcionários no banco de dados
    }

    public function create($funcionario)
    {
        // Lógica para criar um novo funcionário no banco de dados
    }

    public function update($id, $funcionario)
    {
        // Lógica para atualizar um funcionário existente no banco de dados
    }

    public function delete($id)
    {
        // Lógica para excluir um funcionário do banco de dados
    }
}