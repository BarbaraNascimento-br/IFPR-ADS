<?php

//Mostrar erros do PHP
ini_set('display_errors', 1);
error_reporting(E_ALL);

//Configurar essas variáveis de acordo com o seu ambiente
define("DB_HOST", "localhost");
define("DB_NAME", "db_rh_mvc");
define("DB_USER", "root");
define("DB_PASSWORD", "bancodedados");

//Constante para URL do sistema 
define("BASE_URL", "/barb/mvc_alunos_login");

//Outras contantes 