
CREATE TABLE turno (
    id INT AUTO_INCREMENT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    CONSTRAINT pk_turno PRIMARY KEY (id)
);



INSERT INTO turno (nome) VALUES
('Manhã'),
('Tarde'),
('Noite'),
('Integral');



CREATE TABLE cargo (
    id INT AUTO_INCREMENT NOT NULL,
    nome VARCHAR(70) NOT NULL,

    CONSTRAINT pk_cargo PRIMARY KEY (id)
);



INSERT INTO cargo (nome) VALUES
('Gerente'),
('Analista de RH'),
('Assistente Administrativo'),
('Desenvolvedor'),
('Auxiliar de Serviços Gerais');



CREATE TABLE funcionario (
    id INT AUTO_INCREMENT NOT NULL,
    nome VARCHAR(70) NOT NULL,
    email VARCHAR(100) NOT NULL,
    id_turno INT NOT NULL,
    id_cargo INT NOT NULL,

    CONSTRAINT pk_funcionario PRIMARY KEY (id),

    CONSTRAINT fk_funcionario_turno FOREIGN KEY (id_turno)
        REFERENCES turno(id),

    CONSTRAINT fk_funcionario_cargo FOREIGN KEY (id_cargo)
        REFERENCES cargo(id)
);