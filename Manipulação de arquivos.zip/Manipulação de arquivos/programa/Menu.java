import java.util.Scanner;

public class Menu {
    public static void main(String[] args) throws Exception{

        double margem = 20;
        String nomeArquivoDeEntrada;

        Scanner leitura = new Scanner(System.in);
        LeituraPrecoCusto leituraPrecoCusto = new LeituraPrecoCusto();

        System.out.println("Informe o nome do arquivo de entrada: ");
        nomeArquivoDeEntrada = leitura.nextLine();

        System.out.println("Infome a margem : ");
        margem = Double.parseDouble(leitura.nextLine().replace(",", "."));

        leituraPrecoCusto.calcularMargemPrecoVenda(margem, "teste");

    }
}
