public class Retangulo implements FormaGeometricaInterface{
    
    private  float valorA;
    private  float valorB;



    public float getValorA() {
        return valorA;
    }

    public void setValorA(float valorA) {
        this.valorA = valorA;
    }

    public float getValorB() {
        return valorB;
    }

    public void setValorB(float valorB) {
        this.valorB = valorB;
    }




    @Override 
    public float calcularArea(){
        float area =  getValorA() * getValorB();
        return area;
    }


}
