public class menu {
    
    public static void main(String[] args) {
        
        Circulo circulo = new Circulo();
        Quadrado quadrado = new Quadrado();
        Retangulo retangulo = new Retangulo();



        System.out.println("Area do quadrado de lado 3:");
        quadrado.setValorA(3);
        System.out.println(quadrado.calcularArea());

        System.out.println("Area do retangulo de base 2 e altura 4:");
        retangulo.setValorA(2);
        retangulo.setValorB(4);
        System.out.println(retangulo.calcularArea());

        System.out.println("Area do circulo de raio 3: ");
        circulo.setRaio(3);
        System.out.println(circulo.calcularArea());

    }

}
