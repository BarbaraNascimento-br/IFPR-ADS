public class Quadrado implements FormaGeometricaInterface{

    private float valorA;

    
    @Override 
    public float calcularArea(){
        float area =  getValorA() * getValorA();
        return area;
    }


    public float getValorA() {
        return valorA;
    }


    public void setValorA(float valorA) {
        this.valorA = valorA;
    }

    
}