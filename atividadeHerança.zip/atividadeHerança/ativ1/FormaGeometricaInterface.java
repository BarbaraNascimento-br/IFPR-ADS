public interface FormaGeometricaInterface {

    public float calcularArea();
    
}