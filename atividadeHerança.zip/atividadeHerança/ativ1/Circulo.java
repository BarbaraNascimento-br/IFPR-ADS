public class Circulo implements FormaGeometricaInterface{

    private float raio;

    
    
    @Override 
    public float calcularArea(){
        float pi = 3.14f;
        float area =  getRaio() * 2 * pi;
        return area;
    }



    public float getRaio() {
        return raio;
    }



    public void setRaio(float raio) {
        this.raio = raio;
    }



    
}
